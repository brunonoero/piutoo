using Piootoo.Shared.Configuration;
using Piootoo.Strategies.Easy.Engines;

namespace Piootoo.Strategies.PiutooStrategies;

/// <summary>
/// PTS_NQ_TFM_010_60 — TF_M su NQ a 60 minuti, famiglia 02 della consegna
/// <c>run_20260820_0856</c> (dossier S02).
///
/// <para>Trend following simmetrico: stop buy su <c>H_d1</c>, stop sell su <c>L_d1</c>. I gate
/// neutri sono comuni ai due versi, quelli direzionali sono speculari — il motore applica il
/// segno per verso.</para>
///
/// <para><b>Sessione e fuso.</b> Le sessioni <c>d0..d5</c> su cui girano i pattern sono il
/// <b>giorno di calendario europeo</b>, 00:00 → 00:00, come il motore Python che taglia con
/// <c>(timestamp − 1 min − session_start_hour).normalize()</c> e <c>session_start_hour = 0</c>.
/// Non è la sessione del broker, ed è una scelta di modello della ricerca che il port riproduce
/// tale e quale: le due coincidono quasi sempre — mezzanotte a Roma sono le 17:00 a Chicago — ma
/// non nelle settimane in cui l'ora legale americana ed europea non sono allineate. Lo stesso
/// confine governa il secchio di <c>MaxEntriesPerSession</c>, quindi vale per pattern e limite di
/// fill insieme.</para>
///
/// <para><b>Niente dipende da come è stampato il feed.</b> Sessione e finestra dichiarano il
/// proprio fuso e il confronto passa dall'istante assoluto della barra: il feed dichiara il suo
/// orologio in <c>datafeed/feed-clocks.json</c> e viene convertito a UTC vero al caricamento.
/// Vedi <c>docs/domini/orari-di-sessione-e-fusi.md</c>.</para>
///
/// <para><b>Filtri pattern.</b></para>
/// <para><b>Filtro comune a long e short</b></para>
/// <list type="bullet">
/// <item><description>deve essere VERO — neutrale 47: <c>(H_d1-L_d1) &lt; ((H_d2-L_d2) + (H_d3-L_d3)) / 2</c></description></item>
/// <item><description>deve essere FALSO — neutrale 11: <c>|O_d5-C_d1| &lt; 0.5 * (H_d5-L_d1)</c></description></item>
/// </list>
/// <para><b>Solo LONG</b></para>
/// <list type="bullet">
/// <item><description>deve essere VERO — direzionale -34: <c>L_d1 &gt; L_d5</c></description></item>
/// <item><description>deve essere FALSO — direzionale 28: <c>L_d0 &gt; L_d1 * (1 + 0.005)</c></description></item>
/// </list>
/// <para><b>Solo SHORT</b></para>
/// <list type="bullet">
/// <item><description>deve essere VERO — direzionale -34: <c>H_d1 &lt; H_d5</c></description></item>
/// <item><description>deve essere FALSO — direzionale 28: <c>H_d0 &lt; H_d1 * (1 - 0.005)</c></description></item>
/// </list>
///
/// <para><b>Quando può operare.</b></para>
/// <list type="bullet">
/// <item><description>Opera solo fra 00:00 e 17:00, ora dei dati (CET)</description></item>
/// <item><description>Nessun giorno escluso</description></item>
/// <item><description>Può restare aperta oltre la sessione (multiday)</description></item>
/// <item><description>Al massimo una entrata per sessione e per direzione</description></item>
/// </list>
///
/// <para><b>Uscite.</b> Sono autocontenute nel segnale di ingresso e vengono applicate
/// dall'engine o dal broker: la strategia non emette mai segnali di chiusura.</para>
/// <list type="bullet">
/// <item><description>Stop loss: $2,500 per contratto = 125.00 pt</description></item>
/// <item><description>Take profit: $5,000 = 250.00 pt</description></item>
/// <item><description>Uscita a tempo dopo 48 barre (2.0 giorni di calendario)</description></item>
/// </list>
///
/// <para><b>Contratto di riferimento:</b> NQ, $20 per punto, tick 0,25 punti.</para>
///
/// <para><b>Metriche di validazione storica — non sono garanzie di rendimento.</b></para>
/// <list type="table">
/// <listheader><term>Metrica</term><description>Valore</description></listheader>
/// <item><term>Atteso per trade</term><description>$422.4</description></item>
/// <item><term>Out-of-sample</term><description>$49,592 su 112 trade &#183; drawdown $20,581 &#183; profit factor 1.34 &#183; $443 per trade.</description></item>
/// <item><term>Plateau minimo</term><description>0.78</description></item>
/// <item><term>Efficienza Walk-Forward</term><description>0.95</description></item>
/// <item><term>Monte Carlo drawdown p95</term><description>$42,791</description></item>
/// </list>
///
/// <para><b>Verifica del porting:</b> lista trade di riferimento
/// <c>run-engine/run-06-gosto/consegna/trades/fam02_TF_M.csv</c> (456 trade totali, 112 OOS,
/// 2012-01-10 → 2025-05-15).</para>
/// </summary>
public sealed class PTS_NQ_TFM_010_60 : TfMirroredEngine
{
    public override string Name => "PTS_NQ_TFM_010_60";
    public override string Description =>
        "TF_M NQ 60m: famiglia 02 run 20260820, finestra 00:00–17:00 CET, multiday";
    public override string Symbol => "@NQ";
    public override int TimeframeMinutes => 60;

    public PTS_NQ_TFM_010_60()
    {
        // Confine di sessione del run: giorno di calendario europeo, come
        // (timestamp - 1 min - session_start_hour).normalize() del motore Python.
        // NON e' la sessione del broker: le due divergono nelle settimane di
        // disallineamento fra ora legale americana ed europea.
        Session = ZonedWindow.ResearchSession();
        Contracts = 1;

        // Finestra operativa: start_hour/end_hour del run, verbatim nell'orologio
        // della ricerca. Nessuna conversione: il fuso viaggia con il dato.
        TradingWindow = ZonedWindow.ResearchHours(0, 17);
        SkipDay = -1;   // skip_day (0 = lunedì, -1 = nessuno)

        NeutralYes = 47;      // ptn_neut_yes
        NeutralNo = 11;       // ptn_neut_no
        DirectionalYes = -34; // ptn_dir_yes
        DirectionalNo = 28;   // ptn_dir_no

        IntradayOnly = false; // intraday_only

        StopMoney = 2500;   // stop_loss, $ per contratto = 125.00 pt
        ProfitMoney = 5000; // take_profit, $ per contratto = 250.00 pt
        MaxBars = 48;       // max_bars
    }

    public void Initialize(Dictionary<string, object>? parameters = null)
    {
        if (parameters is null) return;
        if (parameters.TryGetValue("Contracts", out var contracts))
            Contracts = Convert.ToInt32(contracts);
        if (parameters.TryGetValue("StopLoss", out var stopLoss))
            StopMoney = Convert.ToInt32(stopLoss);
        if (parameters.TryGetValue("TakeProfit", out var takeProfit))
            ProfitMoney = Convert.ToInt32(takeProfit);
        if (parameters.TryGetValue("MaxBars", out var maxBars))
            MaxBars = Convert.ToInt32(maxBars);
        if (parameters.TryGetValue("PtnNeutYes", out var neutYes))
            NeutralYes = Convert.ToInt32(neutYes);
        if (parameters.TryGetValue("PtnNeutNo", out var neutNo))
            NeutralNo = Convert.ToInt32(neutNo);
        if (parameters.TryGetValue("PtnDirYes", out var dirYes))
            DirectionalYes = Convert.ToInt32(dirYes);
        if (parameters.TryGetValue("PtnDirNo", out var dirNo))
            DirectionalNo = Convert.ToInt32(dirNo);
        if (parameters.TryGetValue("StartHour", out var startHour))
            TradingWindow = TradingWindow! with { StartHhmm = Convert.ToInt32(startHour) * 100 };
        if (parameters.TryGetValue("EndHour", out var endHour))
            TradingWindow = TradingWindow! with { EndHhmm = Convert.ToInt32(endHour) * 100 };
    }
}
