using Piootoo.Shared.Interfaces;
using Piootoo.Strategies.Easy.Engines;

namespace Piootoo.Strategies.PiutooStrategies;

/// <summary>
/// PTS_NQ_PCH_006_30 — PC su NQ a 30 minuti, famiglia 05 della consegna
/// <c>run_20260815_1021</c>.
///
/// <para>Breakout del canale di Donchian calcolato sulle barre, non sulle sessioni.</para>
///
/// <para><b>Sessione e fuso.</b> Le sessioni <c>d0..d5</c> su cui girano i pattern sono
/// ricostruite dalle barre intraday con confine a mezzanotte, come nella ricerca: la
/// sessione è il giorno di calendario del feed, non la sessione CME 17:00–16:00. Per questo
/// <c>SessionStartTime</c> = 0 e <c>SessionEndTime</c> = 2359. Lo stesso confine governa il
/// secchio di <c>MaxEntriesPerSession</c>, quindi vale per pattern e limite di fill insieme.</para>
///
/// <para><b>Filtri pattern.</b></para>
/// <para><b>Filtro comune a long e short</b></para>
/// <list type="bullet">
/// <item><description>deve essere VERO — neutrale 3: <c>|O_d1-C_d1| &lt; 0.5 * (H_d1-L_d1)</c></description></item>
/// <item><description>deve essere FALSO — neutrale 24: <c>|O_d5-C_d1| &lt; 0.25 * (HH5-LL5)</c></description></item>
/// </list>
/// <para><b>Solo LONG</b></para>
/// <list type="bullet">
/// <item><description>deve essere VERO — direzionale -48: <c>close &lt; O_d0 * 1.005</c></description></item>
/// </list>
/// <para><b>Solo SHORT</b></para>
/// <list type="bullet">
/// <item><description>deve essere VERO — direzionale -48: <c>close &gt; O_d0 * 0.995</c></description></item>
/// </list>
///
/// <para><b>Quando può operare.</b></para>
/// <list type="bullet">
/// <item><description>Opera solo fra 11:00 e 10:00 (a cavallo della mezzanotte), ora dei dati (CET)</description></item>
/// <item><description>Può restare aperta oltre la sessione (multiday)</description></item>
/// <item><description>Al massimo una entrata per sessione e per direzione</description></item>
/// </list>
///
/// <para><b>Uscite.</b> Sono autocontenute nel segnale di ingresso e vengono applicate
/// dall'engine o dal broker: la strategia non emette mai segnali di chiusura.</para>
/// <list type="bullet">
/// <item><description>Stop loss: $2,250 per contratto = 112.50 pt</description></item>
/// <item><description>Take profit: $10,000 = 500.00 pt</description></item>
/// <item><description>Trailing stop: $2,000 = 100.00 pt</description></item>
/// <item><description>Breakeven a $500 = 25.00 pt di utile</description></item>
/// <item><description>Nessuna uscita a tempo</description></item>
/// </list>
///
/// <para><b>Contratto di riferimento:</b> NQ, $20 per punto, tick 0,25 punti.</para>
///
/// <para><b>Metriche di validazione storica — non sono garanzie di rendimento.</b></para>
/// <list type="table">
/// <listheader><term>Metrica</term><description>Valore</description></listheader>
/// <item><term>Atteso per trade</term><description>$116.0</description></item>
/// <item><term>Out-of-sample</term><description>$62,239 su 199 trade &#183; drawdown $17,287 &#183; profit factor 1.67 &#183; $313 per trade.</description></item>
/// <item><term>Plateau minimo</term><description>0.59</description></item>
/// <item><term>Efficienza Walk-Forward</term><description>0.37</description></item>
/// <item><term>Monte Carlo drawdown p95</term><description>$22,533</description></item>
/// </list>
/// </summary>
/// <remarks>
/// <para><b>Disabilitata: doppione di <see cref="PTS_NQ_PCH_004_30"/>.</b> La ricerca la elenca fra le equivalenti della capofila di famiglia 05: stessi ordini di entrata.
/// Il gate <c>ptn_dir_no = 53</c> cade nel <c>default =&gt; false</c> del motore: non e' un filtro
/// con soglia altissima, e' nessun filtro.</para>
///
/// <para>Il dossier <c>run-engine/run-01-agosto/dossier_ctrader_NQ.md</c> conta 15 strategie
/// univoche, non 18, perche' deduplica anche fra timeframe diversi: questa non compare, e la
/// capofila corrispondente e' <c>S12</c>.</para>
///
/// <para><b>Perche' resta nel repository.</b> Il sorgente documenta una riga approvata dalla
/// ricerca e serve a rifare il confronto con la capofila. Ma non deve finire in un masterfilter:
/// due sistemi che mandano gli stessi ordini su conti separati sono copy trading, e presso una
/// prop firm costano il conto (dossier §6). L'attributo la toglie dal catalogo lasciandola
/// istanziabile per nome.</para>
/// </remarks>
[StrategiaDisabilitata(
    "Doppione di PTS_NQ_PCH_004_30: stessi ordini di entrata. Vedi dossier_ctrader_NQ.md §6.")]
public sealed class PTS_NQ_PCH_006_30 : PriceChannelEngine
{
    public override string Name => "PTS_NQ_PCH_006_30";
    public override string Description =>
        "PC NQ 30m: famiglia 05 run 20260815, finestra 04:00–03:00 Chicago, multiday";
    public override string Symbol => "@NQ";
    public override int TimeframeMinutes => 30;

    public PTS_NQ_PCH_006_30()
    {
        // Sessione = giorno di calendario del feed, come la ricerca.
        SessionStartTime = 1700;   // riapertura CME, ora di Chicago
        SessionEndTime = 1600;    // chiusura CME, ora di Chicago
        Contracts = 1;

        ChannelBars = 50; // channel_len
        Direction = 1;    // direction: 1 = solo long
        OffsetTicks = 2;  // breakout_offset_ticks
        TickSize = 0.25m; // tick NQ
        DvolMin = 0m;     // dvol_min: filtro di volatilità disattivo

        StartTime = 400; // start_hour
        EndTime = 300;   // end_hour
        SkipDay = -1;     // skip_day (0 = lunedì, -1 = nessuno)

        NeutralYes = 3;       // ptn_neut_yes
        NeutralNo = 24;       // ptn_neut_no
        DirectionalYes = -48; // ptn_dir_yes
        DirectionalNo = 53;   // ptn_dir_no

        IntradayOnly = false; // intraday_only

        StopMoney = 2250;         // stop_loss, $ per contratto = 112.50 pt
        ProfitMoney = 10000;      // take_profit, $ per contratto
        TrailingStopMoney = 2000; // trailing_stop
        BreakEvenMoney = 500;     // breakeven
        MaxBars = 0;              // max_bars  (0 = nessuna uscita a tempo)
    }

    public void Initialize(Dictionary<string, object>? parameters = null)
    {
        if (parameters is null) return;
        if (parameters.TryGetValue("Contracts", out var contracts))
            Contracts = Convert.ToInt32(contracts);
        if (parameters.TryGetValue("StopLoss", out var stopLoss))
            StopMoney = Convert.ToInt32(stopLoss);
        if (parameters.TryGetValue("TakeProfit", out var takeProfit))
            ProfitMoney = Convert.ToInt32(takeProfit);
        if (parameters.TryGetValue("MaxBars", out var maxBars))
            MaxBars = Convert.ToInt32(maxBars);
        if (parameters.TryGetValue("TrailingStop", out var trailingStop))
            TrailingStopMoney = Convert.ToInt32(trailingStop);
        if (parameters.TryGetValue("BreakEven", out var breakEven))
            BreakEvenMoney = Convert.ToInt32(breakEven);
        if (parameters.TryGetValue("ChannelLength", out var channelLength))
            ChannelBars = Convert.ToInt32(channelLength);
        if (parameters.TryGetValue("PtnNeutYes", out var neutYes))
            NeutralYes = Convert.ToInt32(neutYes);
        if (parameters.TryGetValue("PtnNeutNo", out var neutNo))
            NeutralNo = Convert.ToInt32(neutNo);
        if (parameters.TryGetValue("PtnDirYes", out var dirYes))
            DirectionalYes = Convert.ToInt32(dirYes);
        if (parameters.TryGetValue("PtnDirNo", out var dirNo))
            DirectionalNo = Convert.ToInt32(dirNo);
        if (parameters.TryGetValue("StartHour", out var startHour))
            StartTime = Convert.ToInt32(startHour) * 100;
        if (parameters.TryGetValue("EndHour", out var endHour))
            EndTime = Convert.ToInt32(endHour) * 100;
    }
}
