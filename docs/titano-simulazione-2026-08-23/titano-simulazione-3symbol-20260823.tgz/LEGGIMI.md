# Simulazione Titano — backtest a 3 symbol, 23/08/2026

Sorgente: `piootoo-repository/trades.jsonl` — sessione `a35e1521`
220 trade, 26 strategie, NQ 156 + ES 45 + GC 19, 24/06/2025 → 10/10/2025, netto +51.708

**Il run è incompleto**: il file è il journal, si ferma al 10/10 e `trades.json` è ancora `[]`.

| Script | Cosa fa |
|---|---|
| `titano.py` | Simulatore Titano v2. Cambiare `SRC` col percorso del jsonl. |
| `run2.py` | Baseline, Titano su varie cadenze/cancelli, sweep del limite giornaliero. |
| `run3.py` | Walk-forward (IS fino al 30/09), stop per strategia (48 combinazioni), tabelle mensili. |
| `mk2.py` | Genera i punti delle curve di equity per il report HTML. |

## Risultato

1. Ottobre −25.323 in 8 sedute; tre giornate (1, 3, 10 ott) valgono −25.393.
2. Causa: SBO_002 (−8.062), SBO_001 (−5.647), TFM_002 (−2.965) — le tre migliori
   strategie dei tre mesi precedenti (+48.310 insieme).
3. Titano non lo evita in nessuna configurazione, e costa: 51.708 → 11.873.
4. Limite di perdita giornaliero 2.000: netto **70.973**, maxDD **15.397**,
   ottobre −11.120. Walk-forward onesto (soglia 1.250 scelta solo su giu–set):
   ottobre da −25.323 a −8.993. Beneficio monotono in tutte le soglie.
5. Stop per strategia: 48 combinazioni, la migliore +56.041 con maxDD 23.031. Non è un fix.
6. «Solo utile» non è raggiungibile: restano 2 mesi negativi su 5.
