import sys, datetime as dt, json, collections
sys.path.insert(0,'/tmp/sim'); import titano as T
UTC=dt.timezone.utc; rows=T.load()
def dl(rs,l,key='net'):
    out=[];cur=None;acc=0.0;stop=False
    for r in sorted(rs,key=lambda x:(x['exit'],x['tradeId'])):
        d=r['exit'].date()
        if d!=cur: cur=d;acc=0.0;stop=False
        if stop: continue
        out.append(r);acc+=r[key]
        if acc<=-l: stop=True
    return out
def cv(rs,key='net'):
    e=0.0;p=[]
    for r in sorted(rs,key=lambda x:(x['exit'],x['tradeId'])): e+=r[key];p.append((r['exit'],e))
    return p
c=T.Cfg(rotationPeriod='Weekly'); d,_=T.run(rows,c); tit,_=T.apply(rows,d,c)
S={'baseline':cv(rows),'lim2000':cv(dl(rows,2000)),'titano':cv(tit,'adj')}
t0=min(p[0] for p in S['baseline']); t1=max(p[0] for p in S['baseline']); span=(t1-t0).total_seconds()
lo=min(0,min(min(v for _,v in s) for s in S.values())); hi=max(max(v for _,v in s) for s in S.values())
W,H=1000,340
def poly(pts): return " ".join(f"{(ts-t0).total_seconds()/span*W:.1f},{H-(v-lo)/(hi-lo)*H:.1f}" for ts,v in pts)
out={k:poly(v) for k,v in S.items()}
out['_grid']=[(l,H-(v-lo)/(hi-lo)*H) for l,v in [('0',0),('+25k',25000),('+50k',50000),('+75k',75000)]]
mt=[];cc=dt.datetime(2025,7,1,tzinfo=UTC)
while cc<t1: mt.append((cc.strftime('%b %y'),(cc-t0).total_seconds()/span*W)); cc=(cc.replace(day=28)+dt.timedelta(days=4)).replace(day=1)
out['_months']=mt
out['_zero']=H-(0-lo)/(hi-lo)*H
out['_oct']=(dt.datetime(2025,10,1,tzinfo=UTC)-t0).total_seconds()/span*W
json.dump(out,open('/tmp/sim/curve2.json','w'),default=str)
print('lo',lo,'hi',hi,'oct x',out['_oct'],'zero',out['_zero'])
