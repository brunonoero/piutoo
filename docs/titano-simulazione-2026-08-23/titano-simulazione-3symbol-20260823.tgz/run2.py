import sys, datetime as dt, collections
sys.path.insert(0,'/tmp/sim')
import titano as T
UTC=dt.timezone.utc
rows=T.load(); CAP=100_000.0
CUT=dt.datetime(2025,10,1,tzinfo=UTC)

def dl(rs,limit,key='net'):
    out=[];cur=None;acc=0.0;stop=False
    for r in sorted(rs,key=lambda x:(x['exit'],x['tradeId'])):
        d=r['exit'].date()
        if d!=cur: cur=d;acc=0.0;stop=False
        if stop: continue
        out.append(r); acc+=r[key]
        if acc<=-limit: stop=True
    return out

def st(rs,key='net'):
    e=CAP;peak=CAP;mdd=0.0;pkts=None
    for r in sorted(rs,key=lambda x:(x['exit'],x['tradeId'])):
        e+=r[key]
        if e>peak: peak=e;pkts=r['exit']
        mdd=max(mdd,peak-e)
    late=sum(r[key] for r in rs if r['exit']>=CUT)
    m=collections.OrderedDict()
    for r in sorted(rs,key=lambda x:x['exit']): k=r['exit'].strftime('%Y-%m'); m[k]=m.get(k,0)+r[key]
    return dict(net=e-CAP,mdd=mdd,gb=peak-e,late=late,n=len(rs),mon=m,
                negm=sum(1 for v in m.values() if v<0),pk=peak-CAP,pkts=pkts)

def show(n,s):
    print(f"{n:38} net={s['net']:9.0f} mdd={s['mdd']:8.0f} picco={s['pk']:8.0f} restit.={s['gb']:8.0f} ott={s['late']:9.0f} mesi<0={s['negm']} n={s['n']:4d}")

b=st(rows); print("="*128); show('BASELINE',b); print(f"   picco il {b['pkts']:%d/%m/%Y}"); print()

print("--- Titano v2 ---")
for per in ['Weekly','Biweekly','Monthly']:
    c=T.Cfg(rotationPeriod=per); d,_=T.run(rows,c); a,_=T.apply(rows,d,c)
    show(f'Titano {per}', st(a,'adj'))
for mpf in [3,5]:
    c=T.Cfg(rotationPeriod='Weekly',minimumPassingFilters=mpf); d,_=T.run(rows,c); a,_=T.apply(rows,d,c)
    show(f'Titano Weekly minPass={mpf}', st(a,'adj'))
for cur,obs in [(0.06,0.12),(0.03,0.06)]:
    c=T.Cfg(rotationPeriod='Weekly',maximumCurrentDrawdown=cur,maximumObservedDrawdown=obs,reenableMaximumCurrentDrawdown=cur*0.6)
    d,_=T.run(rows,c); a,_=T.apply(rows,d,c)
    show(f'Titano DD cur<={cur} obs<={obs}', st(a,'adj'))
print()
print("--- Limite di perdita giornaliero ---")
for lim in [1500,2000,2500,3000,4000,5000,6000,8000,10000]:
    show(f'  limite {lim}', st(dl(rows,lim)))
