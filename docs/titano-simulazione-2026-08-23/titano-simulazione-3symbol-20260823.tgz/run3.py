import sys, datetime as dt, collections
sys.path.insert(0,'/tmp/sim')
import titano as T
UTC=dt.timezone.utc
rows=T.load(); CAP=100_000.0
CUT=dt.datetime(2025,10,1,tzinfo=UTC)
def dl(rs,l,key='net'):
    out=[];cur=None;acc=0.0;stop=False
    for r in sorted(rs,key=lambda x:(x['exit'],x['tradeId'])):
        d=r['exit'].date()
        if d!=cur: cur=d;acc=0.0;stop=False
        if stop: continue
        out.append(r);acc+=r[key]
        if acc<=-l: stop=True
    return out
def nm(rs,key='net'):
    e=CAP;pk=CAP;mdd=0
    for r in sorted(rs,key=lambda x:x['exit']): e+=r[key];pk=max(pk,e);mdd=max(mdd,pk-e)
    return e-CAP,mdd

IS=[r for r in rows if r['exit']<CUT]; OOS=[r for r in rows if r['exit']>=CUT]
best=None;bc=-9
for l in range(1000,12001,250):
    n,m=nm(dl(IS,l)); c=n/m if m else 0
    if c>bc: bc=c;best=l
print("WALK-FORWARD  IS = 24/06 -> 30/09 (191 trade)  |  OOS = 01/10 -> 10/10 (29 trade)")
print(f"  limite scelto solo in-sample: {best}  (Calmar IS {bc:.2f})")
full=dl(rows,best); o=[r for r in full if r['exit']>=CUT]
print(f"  OOS ottobre senza limite: {sum(r['net'] for r in OOS):9.0f}   ({len(OOS)} trade)")
print(f"  OOS ottobre con  limite : {sum(r['net'] for r in o):9.0f}   ({len(o)} trade)")
print()
print("  robustezza OOS su tutte le soglie:")
for l in range(1000,10001,1000):
    o=[r for r in dl(rows,l) if r['exit']>=CUT]
    print(f"     {l:6d}  {sum(r['net'] for r in o):9.0f}")
print(f"     {'nessuna':>6}  {sum(r['net'] for r in OOS):9.0f}")
print()
print("="*100)
print("STOP PER STRATEGIA su P&L rolling (48 combinazioni) — migliori 6 per netto")
def rs_(rs,w,th,cd,key='net'):
    hist=collections.defaultdict(list);off={};out=[]
    for r in sorted(rs,key=lambda x:(x['exit'],x['tradeId'])):
        c=r['strategyCode']; u=off.get(c)
        if not(u is not None and r['entry']<u): out.append(r)
        hist[c].append((r['exit'],r[key]))
        w_=[v for (ts,v) in hist[c] if ts>r['exit']-dt.timedelta(days=w)]
        if sum(w_)<=-th: off[c]=r['exit']+dt.timedelta(days=cd)
    return out
res=[]
for w in [14,21,30,45]:
    for th in [2000,3000,4000,6000]:
        for cd in [14,21,30]:
            f=rs_(rows,w,th,cd); n,m=nm(f)
            res.append((n,m,sum(r['net'] for r in f if r['exit']>=CUT),w,th,cd,len(f)))
res.sort(key=lambda x:-x[0])
for n,m,la,w,th,cd,ln in res[:6]:
    print(f"  fin.{w}g soglia -{th} stop {cd}g   net={n:9.0f} mdd={m:8.0f} ott={la:9.0f} n={ln}")
print(f"  {'BASELINE':32}   net={nm(rows)[0]:9.0f} mdd={nm(rows)[1]:8.0f} ott={sum(r['net'] for r in OOS):9.0f} n={len(rows)}")
print()
print("="*100)
print("MESE PER MESE")
c=T.Cfg(rotationPeriod='Weekly'); d,_=T.run(rows,c); tit,_=T.apply(rows,d,c)
def mon(rs,key='net'):
    m=collections.OrderedDict()
    for r in sorted(rs,key=lambda x:x['exit']): k=r['exit'].strftime('%Y-%m'); m[k]=m.get(k,0)+r[key]
    return m
V={'baseline':(rows,'net'),'limite 2000':(dl(rows,2000),'net'),'Titano Weekly':(tit,'adj'),'Titano+lim2000':(dl(tit,2000,'adj'),'adj')}
ks=sorted(mon(rows))
print(f"{'mese':9}"+"".join(f"{k:>18}" for k in V))
for k in ks:
    print(f"{k:9}"+"".join(f"{mon(rs,key).get(k,0):18.0f}" for rs,key in V.values()))
print("-"*(9+18*len(V)))
print(f"{'NETTO':9}"+"".join(f"{nm(rs,key)[0]:18.0f}" for rs,key in V.values()))
print(f"{'maxDD':9}"+"".join(f"{nm(rs,key)[1]:18.0f}" for rs,key in V.values()))
print(f"{'trade':9}"+"".join(f"{len(rs):18d}" for rs,key in V.values()))
print()
f=dl(rows,2000); kept=set(r['tradeId'] for r in f); cut=[r for r in rows if r['tradeId'] not in kept]
ag=collections.defaultdict(float)
for r in cut: ag[r['exit'].date()]+=r['net']
print(f"limite 2000: esclusi {len(cut)} trade su {len(ag)} giornate, P&L evitato {sum(r['net'] for r in cut):.0f}")
print("  giornate evitate:"); 
for k,v in sorted(ag.items(),key=lambda x:x[1])[:6]: print(f"     {k}  {v:9.0f}")
print("  utile sacrificato:")
for k,v in sorted(ag.items(),key=lambda x:-x[1])[:4]: print(f"     {k}  {v:9.0f}")
